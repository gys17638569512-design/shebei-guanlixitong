import { createRouter, createWebHistory } from 'vue-router'
import { getPortalPermissions } from '../utils/portalAuth'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue'),
    meta: { title: '客户登录' }
  },
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue'),
    meta: { title: '首页', requiresAuth: true }
  },
  {
    path: '/equipments',
    name: 'EquipmentList',
    component: () => import('../views/EquipmentList.vue'),
    meta: { title: '设备一览', requiresAuth: true }
  },
  {
    path: '/records',
    name: 'OrderList',
    component: () => import('../views/OrderList.vue'),
    meta: { title: '我的维保记录', requiresAuth: true }
  },
  {
    path: '/orders/:id',
    name: 'OrderDetail',
    component: () => import('../views/OrderDetail.vue'),
    meta: { title: '详情', requiresAuth: true }
  },
  {
    path: '/sign/:id',
    name: 'OrderSign',
    component: () => import('../views/OrderSign.vue'),
    meta: { title: '确认签字', requiresAuth: true, permission: 'canSignOrders' }
  },
  {
    path: '/account-center',
    alias: ['/profile'],
    name: 'AccountCenter',
    component: () => import('../views/Profile.vue'),
    meta: { title: '账号中心', requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  // 设置页面标题
  if (to.meta.title) {
    document.title = `${to.meta.title} - 数字化起重机维修维保系统`
  } else {
    document.title = '数字化起重机维修维保系统'
  }

  const token = localStorage.getItem('portal_token')
  if (to.meta.requiresAuth && !token) {
    next('/login')
    return
  }

  if (to.meta.permission) {
    const permissions = getPortalPermissions()
    if (!permissions[to.meta.permission]) {
      next('/records')
      return
    }
  }

  if (to.meta.requiresAuth && token) {
    next()
  } else {
    next()
  }
})

export default router
